create database Prueba6;

use Prueba6;

create table tblPersona
	(IdPersona   int not null auto_increment primary key,
	Nombre       varchar(25) not null,
	APaterno     varchar(25) not null,
	AMaterno     varchar(25) not null,
    Edad 		 int not null,
    Correo 		 varchar(50) not null,
    pass_user   varchar(20) not null);


create table tblDireccion (
    IdDireccion     int not null auto_increment,
    Calle  			varchar(20) not null,
    NumInterior		int not null,
    NumExterior 	int not null,
	Colonia 		varchar(20) not null,
    CP 				int not null,
    Municipio 		varchar(20) not null,
    primary key (IdDireccion));

create table tblCatCto
	(IdCto   int not null auto_increment,
	TipoCto    	  varchar(30) not null,
	primary key (IdCto));
    
create table tblRoles
	(IdRoles   int not null auto_increment,
	Tipo       varchar(20) not null,
	primary key (IdRoles));
insert into tblRoles (Tipo) values('Paciente'), ('Medico');

create table tblCatAlergia
	(IdAlergia   	int not null auto_increment,
	Tipo         	varchar(50) not null,
	primary key (IdAlergia));
insert into tblCatAlergia (Tipo) values
('Polvo'),('Polen'),('Cesped'),('Fresas'),('Leche'),
('Mani'),('Picaduras de insecto'),('Moho'),('Perros'),('´Mariscos');

create table tblCatEnfermedad
	(IdEnfermedad  	int not null auto_increment,
	Tipo      		varchar(50) not null,
	primary key (IdEnfermedad));
insert into tblCatEnfermedad (Tipo) values
('Respiratoria'),('Cardiaca'), ('Neurologica'),('Gastritis'),
('Obesidad'),('COVID-19'), ('Conjutivitis'),('Infección en vías urinarias'),
('Influenza'),('Migraña');

    create table tblRelPerRol
	(IdRelPerRol   int not null auto_increment,
	IdPersona      int not null,
	IdRoles        int not null,
    IdDireccion    int not null,
	primary key (IdRelPerRol),
    foreign key (IdRoles)references tblRoles(IdRoles),
    foreign key (IdPersona)references tblPersona(IdPersona),
    foreign key (IdDireccion)references tblDireccion(IdDireccion)
    );
  
create table tblRelPerCto
	(IdRelPerCto   int not null auto_increment,
	IdPersona      int not null,
	IdCto          int not null,
    Descrip        varchar(50) not null,
	primary key (IdRelPerCto),
    foreign key (IdCto)references tblCatCto(IdCto),
    foreign key (IdPersona)references tblPersona(IdPersona)
    );

create table tblEstudios
	(IdEstudios   int not null auto_increment,
    IdPersona int not null,
	Archivo       varchar(30) not null,
	NombreEst     varchar(30) not null,
	primary key (IdEstudios),
    foreign key (IdPersona)references tblPersona(IdPersona)
    );

create table tblEspecialidad
	(IdEspecialidad   int not null auto_increment,
    IdPersona         int not null,
	NombreEsp         varchar(30) not null,
	primary key (IdEspecialidad),
    foreign key (IdPersona) references tblPersona(IdPersona)
    );
  
create table tblConsultas
	(IdConsultas   int not null auto_increment,
    IdPersona int not null,
	Fecha          date not null,
	Diagnostico    varchar(50) not null,
	Tratamiento    varchar(50) not null,
	primary key (IdConsultas),
    foreign key (IdPersona)references tblPersona(IdPersona)
    );

create table tblExpediente
	(IdExpediente   int not null auto_increment,
    IdPersona int not null,
    IdAlergia         int not null,
    IdEnfermedad      int not null,
    Genero varchar(10) not null,
    TipoSangre      varchar(10) not null,
    Peso int not null,
    Talla int not null,
    Adicciones varchar(100) not null,
    Fracturas varchar(100) not null,
    Cirugias varchar(100) not null,
    ProblemasVision varchar(100) not null,
    DescAlergia  	  varchar(100) not null,
    DescEnfermedad    varchar(100) not null,
	primary key (IdExpediente),
    foreign key (IdPersona)references tblPersona(IdPersona),
    foreign key (IdAlergia)references tblCatAlergia(IdAlergia),
    foreign key (IdEnfermedad)references tblCatEnfermedad(IdEnfermedad)
    );

show tables;
select * from tblPersona;
select * from tblDireccion;
select * from tblExpediente;
select * from tblConsultas;
select * from tblEstudios;
select * from tblRoles;
select * from tblEspecialidad;
select * from tblCatAlergia;
select * from tblCatEnfermedad;
select * from tblRelPerRol;
select * from tblCatCto;
select * from tblRelPerCto;
