/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.dao;

import java.io.Serializable;

/**
 *
 * @author fcall
 */
public class Registro implements Serializable{
    
    private Integer IdPerRol;
    private Rol rol;
    private Persona persona;
    private Direccion direccion;

    public Registro()
    {
    }
                     
    public Registro (Rol rol, Persona persona, Direccion direccion) 
    {
        this.rol = rol;
        this.persona = persona;
        this.direccion = direccion;
    }


    public Integer getIdPerRol() {
        return IdPerRol;
    }

    public void setIdPerRol(Integer IdPerRol) {
        this.IdPerRol = IdPerRol;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }
    
    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
}