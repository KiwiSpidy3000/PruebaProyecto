/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.dao;

import java.io.Serializable;

/**
 *
 * @author ofeli
 */
public class Alergia implements Serializable{
    
    private Integer IdAlergia;
    private String Tipo;

    public Alergia() {
        
    }

    public Integer getIdAlergia() {
        return IdAlergia;
    }

    public void setIdAlergia(Integer IdAlergia) {
        this.IdAlergia = IdAlergia;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
}