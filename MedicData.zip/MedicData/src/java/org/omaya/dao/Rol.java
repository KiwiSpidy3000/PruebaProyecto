/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.dao;

import java.io.Serializable;

/**
 *
 * @author alexi
 */
public class Rol implements Serializable
{
    private Integer IdRoles;
    private String Tipo;

    public Rol() {
        
    }

    public Integer getIdRoles() {
        return IdRoles;
    }

    public void setIdRoles(Integer IdRoles) {
        this.IdRoles = IdRoles;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
    
}