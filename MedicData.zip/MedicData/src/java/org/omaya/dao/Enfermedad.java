/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.dao;

import java.io.Serializable;

/**
 *
 * @author ldrnt
 */
public class Enfermedad implements Serializable
{
    private Integer IdEnfermedad;
    private String Tipo;

    public Enfermedad() {
        
    }

    public Integer getIdEnfermedad() {
        return IdEnfermedad;
    }

    public void setIdEnfermedad(Integer IdEnfermedad) {
        this.IdEnfermedad = IdEnfermedad;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
    
}