/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.dao;

import java.io.Serializable;

/**
 *
 * @author Alumno
 */
public class Direccion implements Serializable{
    private Integer IdDireccion;
    private String Calle;
    private Integer NumInterior;
    private Integer NumExterior;
    private String Colonia;
    private Integer CP;
    private String Municipio;

    public Direccion() {
    }

    public Integer getIdDireccion() {
        return IdDireccion;
    }

    public void setIdDireccion(Integer IdDireccion) {
        this.IdDireccion = IdDireccion;
    }

    public String getCalle() {
        return Calle;
    }

    public void setCalle(String Calle) {
        this.Calle = Calle;
    }

    public Integer getNumInterior() {
        return NumInterior;
    }

    public void setNumInterior(Integer NumInterior) {
        this.NumInterior = NumInterior;
    }

    public Integer getNumExterior() {
        return NumExterior;
    }

    public void setNumExterior(Integer NumExterior) {
        this.NumExterior = NumExterior;
    }

    public String getColonia() {
        return Colonia;
    }

    public void setColonia(String Colonia) {
        this.Colonia = Colonia;
    }

    public Integer getCP() {
        return CP;
    }

    public void setCP(Integer CP) {
        this.CP = CP;
    }

    public String getMunicipio() {
        return Municipio;
    }

    public void setMunicipio(String Municipio) {
        this.Municipio = Municipio;
    }
    
    
}
