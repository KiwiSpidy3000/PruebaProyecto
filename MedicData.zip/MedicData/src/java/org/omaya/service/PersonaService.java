/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.omaya.dao.Persona;

/**
 *
 * @author ldrnt
 */
public class PersonaService {
    
    public List<Persona> getPersonaList( )
    {
        List<Persona>personaList = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        Persona persona = null;
        
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            statement = connection.createStatement( );
            if( statement == null )
            {
                return null;
            }
            resultSet = statement.executeQuery( "SELECT * FROM TBLPERSONA" );
            if( resultSet == null )
            {
                return null;
            }
            personaList = new ArrayList<>();
            while( resultSet.next() )
            {
                persona = new Persona();
                persona.setIdPersona( resultSet.getInt(1) );
                persona.setNombre(resultSet.getString(2) );
                persona.setAPaterno(resultSet.getString(3) );
                persona.setAMaterno(resultSet.getString(4) );
                persona.setEdad(resultSet.getInt(5) );
                persona.setCorreo(resultSet.getString(6) );
                persona.setContraseña(resultSet.getString(7) );
                personaList.add(persona);
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return personaList;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean addPersona( Persona persona )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO TBLPERSONA (Nombre, APaterno, AMaterno, Edad, Correo, Contraseña) values(? , ? , ? , ? , ? , ?)";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, persona.getIdPersona());
            preparedStatement.setString(2, persona.getNombre());
            preparedStatement.setString(3, persona.getAPaterno());
            preparedStatement.setString(4, persona.getAMaterno());
            preparedStatement.setInt(5, persona.getEdad());
            preparedStatement.setString(6, persona.getCorreo());
            preparedStatement.setString(7, persona.getContraseña());
            
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }

    public Persona getPersonaByIdPersona( Integer idpersona )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT * FROM TBLPERSONA where IDPERSONA = ?";
        Persona persona = null;
        try 
        {
            connection = MySqlConnection.getConnection();
            if( connection == null )
            {
                return null;
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, idpersona );
            resultSet = preparedStatement.executeQuery();
            if( resultSet == null )
            {
                return null;
            }
            while( resultSet.next() )
            {
                persona = new Persona();
                persona.setIdPersona( resultSet.getInt(1) );
                persona.setNombre(resultSet.getString(2) );
                persona.setAPaterno(resultSet.getString(3) );
                persona.setAMaterno(resultSet.getString(4) );
                persona.setEdad(resultSet.getInt(5) );
                persona.setCorreo(resultSet.getString(6) );
                persona.setContraseña(resultSet.getString(7) );
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return persona;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }

     public boolean updatePersona( Persona persona )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "update TBLPERSONA SET Nombre=?, APaterno=?, AMaterno=?, Edad=?, Correo=?, Contraseña=? where IDPERSONA = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setString(1, persona.getContraseña());
            preparedStatement.setString(2, persona.getCorreo());
            preparedStatement.setInt(3, persona.getEdad());
            preparedStatement.setString(4, persona.getAMaterno());
            preparedStatement.setString(5, persona.getAPaterno());
            preparedStatement.setString(6, persona.getNombre());
            preparedStatement.setInt(7, persona.getIdPersona() );
            
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean deletePersona( Persona persona )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM TBLPERSONA WHERE IDPERSONA = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, persona.getIdPersona());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
}
