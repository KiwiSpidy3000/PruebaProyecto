/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.service;

/**
 *
 * @author fcall
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.omaya.dao.Rol;
import org.omaya.dao.Direccion;
import org.omaya.dao.Registro;
import org.omaya.dao.Persona;

/**
 *
 * @author ldrnt
 */
public class RegistroService 
{
    
    public List<Registro> getRegistroList( )
    {
        List<Registro>registroList = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        Registro registro = null;
        String sql = null;
        Persona persona = null;
        Rol rol = null;
        Direccion direccion = null;
        
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            statement = connection.createStatement( );
            if( statement == null )
            {
                return null;
            }
            sql = "SELECT " +
                    "TBLPERSONA.IdPersona, " +
                    "TBLPERSONA.Nombre, " +
                    "TBLPERSONA.APaterno, "+
                    "TBLPERSONA.AMaterno, "+
                    "TBLPERSONA.Edad, "+
                    "TBLPERSONA.Correo, "+
                    "TBLPERSONA.Contraseña, "+
                    "TBLROLES.IdRoles, "+
                    "TBLROLES.Tipo, "+
                    "TBLDIRECCION.IdDireccion, "+
                    "TBLDIRECCION.Calle, "+
                    "TBLDIRECCION.NumInterior, "+
                    "TBLDIRECCION.NumExterior, "+
                    "TBLDIRECCION.Colonia, "+
                    "TBLDIRECCION.CP, "+
                    "TBLDIRECCION.Municipio "+
                    "FROM TBLRELPERROL "+
                    "INNER JOIN tblRoles ON "+
                    "TBLRELPERROL.tblRoles_IDROLES = tblRoles.IDROLES "+
                    "INNER JOIN tblPersona ON " +
                    "TBLRELPERROL.tblPersona_IDPERSONA = tblPersona.IDPERSONA " +
                    "INNER JOIN tblDireccion ON " +
                    "TBLRELPERROL.tblDireccion_IDDIRECCION = tblDireccion.IDDIRECCION";
            resultSet = statement.executeQuery( sql );
            if( resultSet == null )
            {
                return null;
            }
            registroList = new ArrayList<>();
            while( resultSet.next() )
            {
                registro = new Registro( );
                persona = new Persona( );
                rol = new Rol( );
                direccion = new Direccion( );
                registro.setRol(rol);
                registro.setPersona(persona);
                registro.setDireccion(direccion);
                registro.setIdPerRol(resultSet.getInt(1) );
                persona.setIdPersona(resultSet.getInt(2) );
                persona.setNombre(resultSet.getString(3) );
                persona.setAPaterno(resultSet.getString(4) );
                persona.setAMaterno(resultSet.getString(5) );
                persona.setEdad(resultSet.getInt(6) );
                persona.setCorreo(resultSet.getString(7) );
                persona.setContraseña(resultSet.getString(8) );
                rol.setIdRoles(resultSet.getInt(9) );
                rol.setTipo(resultSet.getString(10) );
                direccion.setIdDireccion(resultSet.getInt(11) );
                direccion.setCalle(resultSet.getString(12) );
                direccion.setNumInterior(resultSet.getInt(13) );
                direccion.setNumExterior(resultSet.getInt(14) );
                direccion.setColonia(resultSet.getString(15) );
                direccion.setCP(resultSet.getInt(16) );
                direccion.setMunicipio(resultSet.getString(17) );
                
                registroList.add(registro);
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return registroList;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean addRegistro( Registro registro )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO TBLRELPERROL (TBLPERSONA_IDPERSONA, TBLROL_IDROLES, TBLDIRECCION_IDDIRECCION) VALUES(?,?,?)";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, registro.getPersona().getIdPersona());
            preparedStatement.setInt(2, registro.getRol().getIdRoles());
            preparedStatement.setInt(3, registro.getDireccion().getIdDireccion());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteRegistro( Registro registro )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM TBLRELPERROL WHERE IDRELPERROL = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, registro.getRol().getIdRoles());
            preparedStatement.setInt(2, registro.getIdPerRol());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public Registro getRegistroById( Integer IdPerRol )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT * FROM TBLRELPERROL WHERE IdPerRol= ?";
        Registro registro = null;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, IdPerRol );
            resultSet = preparedStatement.executeQuery( );
            if( resultSet == null )
            {
                return null;
            }
            while( resultSet.next() )
            {
                registro = new Registro();
                registro.getRol().setTipo(resultSet.getString(1) );
                registro.getRol().setIdRoles(resultSet.getInt(2) );
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return registro;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean updateRegistro( Registro registro )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "update TBLRELPERROL SET TIPO=? WHERE IDROLES = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setString(1, registro.getRol().getTipo());
            preparedStatement.setInt(2, registro.getRol().getIdRoles());
            
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
}
