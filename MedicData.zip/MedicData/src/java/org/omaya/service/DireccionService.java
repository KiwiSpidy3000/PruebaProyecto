/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.omaya.dao.Direccion;
import org.omaya.service.MySqlConnection;

/**
 *
 * @author ldrnt
 */
public class DireccionService {
    
    public List<Direccion> getDireccionList( )
    {
        List<Direccion>direccionList = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        Direccion direccion = null;
        
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            statement = connection.createStatement( );
            if( statement == null )
            {
                return null;
            }
            resultSet = statement.executeQuery( "SELECT * FROM TBLDIRECCION" );
            if( resultSet == null )
            {
                return null;
            }
            direccionList = new ArrayList<>();
            while( resultSet.next() )
            {
                direccion = new Direccion();
                direccion.setIdDireccion( resultSet.getInt(1) );
                direccion.setCalle(resultSet.getString(2) );
                direccion.setNumInterior(resultSet.getInt(3) );
                direccion.setNumExterior(resultSet.getInt(4) );
                direccion.setColonia(resultSet.getString(5) );
                direccion.setCP(resultSet.getInt(6) );
                direccion.setMunicipio(resultSet.getString(7) );
                direccionList.add(direccion);
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return direccionList;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean addDireccion( Direccion direccion )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO TBLDIRECCION (Calle, NumInterior, NumExterior, Colonia, CP, Municipio) values(? , ? , ? , ? , ? , ?)";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, direccion.getIdDireccion());
            preparedStatement.setString(2, direccion.getCalle());
            preparedStatement.setInt(3, direccion.getNumInterior());
            preparedStatement.setInt(4, direccion.getNumExterior());
            preparedStatement.setString(5, direccion.getColonia());
            preparedStatement.setInt(6, direccion.getCP());
            preparedStatement.setString(7, direccion.getMunicipio());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }

    public Direccion getDireccionByIdDireccion( Integer iddireccion )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT * FROM TBLDIRECCION where IDDIRECCION = ?";
        Direccion direccion = null;
        try 
        {
            connection = MySqlConnection.getConnection();
            if( connection == null )
            {
                return null;
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, iddireccion );
            resultSet = preparedStatement.executeQuery();
            if( resultSet == null )
            {
                return null;
            }
            while( resultSet.next() )
            {
                direccion = new Direccion();
                direccion.setIdDireccion( resultSet.getInt(1) );
                direccion.setCalle(resultSet.getString(2) );
                direccion.setNumInterior(resultSet.getInt(3) );
                direccion.setNumExterior(resultSet.getInt(4) );
                direccion.setColonia(resultSet.getString(5) );
                direccion.setCP(resultSet.getInt(6) );
                direccion.setMunicipio(resultSet.getString(7) );
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return direccion;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }

     public boolean updateDireccion( Direccion direccion )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "update TBLDIRECCION SET Calle=?, NumInterior=?, NumExterior=?, Colonia=?, CP=?, Municipio=? where IDDIRECCION = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setString(1, direccion.getMunicipio());
            preparedStatement.setInt(2, direccion.getCP());
            preparedStatement.setString(3, direccion.getColonia());
            preparedStatement.setInt(4, direccion.getNumExterior());
            preparedStatement.setInt(5, direccion.getNumInterior());
            preparedStatement.setString(6, direccion.getCalle());
            preparedStatement.setInt(7, direccion.getIdDireccion() );
            
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteDireccion( Direccion direccion )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM TBLDIRECCION WHERE IDDIRECCION = ?";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setInt(1, direccion.getIdDireccion());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
}
