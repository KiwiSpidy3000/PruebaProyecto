/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.omaya.dao.Alergia;

/**
 *
 * @author ldrnt
 */
public class AlergiaService 
{
    
    public List<Alergia> getAlergiaList( )
    {
        List<Alergia>alergiaList = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        Alergia alergia = null;
        
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            statement = connection.createStatement( );
            if( statement == null )
            {
                return null;
            }
            resultSet = statement.executeQuery( "SELECT * FROM TBLCATALERGIA" );
            if( resultSet == null )
            {
                return null;
            }
            alergiaList = new ArrayList<>();
            while( resultSet.next() )
            {
                alergia = new Alergia();
                alergia.setIdAlergia(resultSet.getInt(1) );
                alergia.setTipo(resultSet.getString(2) );
                alergiaList.add(alergia);
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return alergiaList;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean addAlergia( Alergia alergia )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO TBLCATALERGIAS (TIPO) VALUES (?)";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setString(1, alergia.getTipo());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public Alergia getAlergiaById( Integer idalergia )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT * FROM TBLCATALERGIAS WHERE IDALERGIA= ?";
        Alergia alergia = null;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, idalergia );
            resultSet = preparedStatement.executeQuery( );
            if( resultSet == null )
            {
                return null;
            }
            while( resultSet.next() )
            {
                alergia = new Alergia();
                alergia.setIdAlergia(resultSet.getInt(1) );
                alergia.setTipo(resultSet.getString(2) );
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return alergia;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
  
}