/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.omaya.dao.Enfermedad;

/**
 *
 * @author ldrnt
 */
public class EnfermedadService 
{
    
    public List<Enfermedad> getEnfermedadList( )
    {
        List<Enfermedad>enfermedadList = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        Enfermedad enfermedad = null;
        
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            statement = connection.createStatement( );
            if( statement == null )
            {
                return null;
            }
            resultSet = statement.executeQuery( "SELECT * FROM tblCatEnfermedad" );
            if( resultSet == null )
            {
                return null;
            }
            enfermedadList = new ArrayList<>();
            while( resultSet.next() )
            {
                enfermedad = new Enfermedad();
                enfermedad.setIdEnfermedad(resultSet.getInt(1) );
                enfermedad.setTipo(resultSet.getString(2) );
                enfermedadList.add(enfermedad);
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return enfermedadList;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean addEnfermedad( Enfermedad enfermedad )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO tblCatEnfermedad (TIPO) VALUES (?)";
        int row = 0;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return false;
            }
            preparedStatement = connection.prepareStatement(sql);
            if( preparedStatement == null )
            {
                return false;
            }
            preparedStatement.setString(1, enfermedad.getTipo());
            row = preparedStatement.executeUpdate();
            MySqlConnection.closeConnection(connection);
            return row == 1;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return false;
    }
    
    public Enfermedad getEnfermedadById( Integer idenfermedad )
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT * FROM tblCatEnfermedad WHERE IdEnfermedad= ?";
        Enfermedad enfermedad = null;
        try 
        {
            connection = MySqlConnection.getConnection( );
            if( connection == null )
            {
                return null;
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, idenfermedad );
            resultSet = preparedStatement.executeQuery( );
            if( resultSet == null )
            {
                return null;
            }
            while( resultSet.next() )
            {
                enfermedad = new Enfermedad();
                enfermedad.setIdEnfermedad(resultSet.getInt(1) );
                enfermedad.setTipo(resultSet.getString(2) );
            }
            resultSet.close();
            MySqlConnection.closeConnection(connection);
            return enfermedad;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return null;
    }
  
}