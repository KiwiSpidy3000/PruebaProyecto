/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Direccion;
import org.omaya.service.DireccionService;
/**
 *
 * @author ldrnt
 */
public class DireccionHelper implements Serializable
{
    private List<Direccion>list;
    private Direccion direccion;

    public DireccionHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new DireccionService().getDireccionList();
        return list != null && list.size() > 0;
    }
    
    public boolean addDireccion( HttpServletRequest request )
    {
        direccion = new Direccion( ); 
        direccion.setIdDireccion( getInteger(request.getParameter( "IdDireccion" )) );
        if( direccion.getIdDireccion() == null )
        {
            return false;
        }
        
        
        
        direccion.setCalle( request.getParameter( "Calle" ) );
        if( direccion.getCalle() == null || direccion.getCalle().length() == 0 )
        {
            return false;
        }
        
        direccion.setNumInterior( getInteger(request.getParameter( "NumInterior" ) ));
        if( direccion.getNumInterior() == null)
        {
            return false;
        }
        
        direccion.setNumExterior( getInteger(request.getParameter( "NumExterior" ) ));
        if( direccion.getNumExterior() == null)
        {
            return false;
        }
        
        direccion.setColonia( request.getParameter( "Colonia" ) );
        if( direccion.getColonia() == null || direccion.getColonia().length() == 0 )
        {
            return false;
        }
        
        direccion.setCP( getInteger(request.getParameter( "CP" ) ));
        if( direccion.getCP() == null)
        {
            return false;
        }
        
        direccion.setMunicipio( request.getParameter( "Municipio" ) );
        if( direccion.getMunicipio() == null || direccion.getMunicipio().length() == 0 )
        {
            return false;
        }
        
        return new DireccionService().addDireccion(direccion);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }

    public List<Direccion> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Direccion> list) 
    {
        this.list = list;
    }

    public Direccion getIdDireccion() 
    {
        return direccion;
    }

    public void setIdDireccion(Direccion direccion) 
    {
        this.direccion = direccion;
    }
    
}
