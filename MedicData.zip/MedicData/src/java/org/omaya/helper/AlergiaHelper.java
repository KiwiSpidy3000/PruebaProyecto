/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;
import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Alergia;
import org.omaya.service.AlergiaService;

/**
 *
 * @author ofeli
 */
public class AlergiaHelper implements Serializable{
   
    private List<Alergia>list;
    private Alergia alergia;

    public AlergiaHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new AlergiaService().getAlergiaList();
        return list != null && list.size() > 0;
    }
    
    public boolean addAlergia( HttpServletRequest request )
    {
        alergia = new Alergia( ); 
        alergia.setIdAlergia( getInteger(request.getParameter( "IdAlergia" ) ) );
        if( alergia.getIdAlergia() == null || alergia.getIdAlergia() == 0 )
        {
            return false;
        }
        alergia.setTipo( request.getParameter( "Tipo" ) );
        if( alergia.getTipo() == null || alergia.getTipo().length() == 0 )
        {
            return false;
        }
        return new AlergiaService().addAlergia(alergia);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public List<Alergia> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Alergia> list) 
    {
        this.list = list;
    }

    public Alergia getIdAlergia() 
    {
        return alergia;
    }

    public void setIdAlergia(Alergia alergia) 
    {
        this.alergia = alergia;
    }
    
}