/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;
import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Enfermedad;
import org.omaya.service.EnfermedadService;

/**
 *
 * @author ldrnt
 */
public class EnfermedadHelper implements Serializable{
   
    private List<Enfermedad>list;
    private Enfermedad enfermedad;

    public EnfermedadHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new EnfermedadService().getEnfermedadList();
        return list != null && list.size() > 0;
    }
    
    public boolean addEnfermedad( HttpServletRequest request )
    {
        enfermedad = new Enfermedad( ); 
        enfermedad.setIdEnfermedad( getInteger(request.getParameter( "IdEnfermedad" ) ) );
        if( enfermedad.getIdEnfermedad() == null || enfermedad.getIdEnfermedad() == 0 )
        {
            return false;
        }
        enfermedad.setTipo( request.getParameter( "Tipo" ) );
        if( enfermedad.getTipo() == null || enfermedad.getTipo().length() == 0 )
        {
            return false;
        }
        return new EnfermedadService().addEnfermedad(enfermedad);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public List<Enfermedad> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Enfermedad> list) 
    {
        this.list = list;
    }

    public Enfermedad getIdEnfermedad() 
    {
        return enfermedad;
    }

    public void setIdEnfermedad(Enfermedad enfermedad) 
    {
        this.enfermedad = enfermedad;
    }
    
}