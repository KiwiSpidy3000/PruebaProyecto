/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Persona;
import org.omaya.dao.Rol;
import org.omaya.dao.Direccion;
import org.omaya.dao.Registro;
import org.omaya.service.RegistroService;


/**
 *
 * @author omaya
 */
public class RegistroHelper implements Serializable
{
    private List<Registro>list;
    private Registro registro;

    public RegistroHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new RegistroService().getRegistroList();
        return list != null && list.size() > 0;
    }
    
    public boolean addRegistro( HttpServletRequest request )
    {
        registro = new Registro( ); 
        registro.setIdPerRol(getInteger( request.getParameter( "IdPerRol" )) );
        registro.getPersona().setIdPersona(getInteger(request.getParameter( "IdPersona" )) );
        registro.getPersona().setNombre(request.getParameter( "Nombre" ));
        registro.getPersona().setAPaterno(request.getParameter( "APaterno" ) );
        registro.getPersona().setAMaterno(request.getParameter( "AMaterno" ) );
        registro.getPersona().setEdad(getInteger(request.getParameter( "Edad" )) );
        registro.getPersona().setCorreo(request.getParameter( "Correo" ) );
        registro.getPersona().setContraseña(request.getParameter( "Contraseña" ) );
        if( registro.getPersona().getIdPersona()== null || registro.getPersona().getNombre().length() == 0 || registro.getPersona().getAPaterno().length() == 0
                || registro.getPersona().getAMaterno().length() == 0 || registro.getPersona().getEdad()== null || registro.getPersona().getCorreo().length() == 0
                || registro.getPersona().getContraseña().length() == 0)
        {
            return false;
        }
        
        registro.getRol().setIdRoles(getInteger(request.getParameter( "IdRoles" )) );
        registro.getRol().setTipo(request.getParameter( "Tipo" ) );
        if( registro.getRol().getIdRoles()== null || registro.getRol().getTipo().length() == 0 )
        {
            return false;
        }
        
        registro.getDireccion().setIdDireccion(getInteger(request.getParameter( "IdDireccion" )) );
        registro.getDireccion().setCalle(request.getParameter( "Calle" ));
        registro.getDireccion().setNumInterior(getInteger(request.getParameter( "NumInterior" ) ));
        registro.getDireccion().setNumExterior(getInteger(request.getParameter( "NumExterior" )) );
        registro.getDireccion().setColonia(request.getParameter( "Colonia" ) );
        registro.getDireccion().setCP(getInteger(request.getParameter( "CP" )) );
        registro.getDireccion().setMunicipio(request.getParameter( "Municipio" ) );
        if( registro.getDireccion().getIdDireccion()== null || registro.getDireccion().getCalle().length() == 0
                || registro.getDireccion().getNumInterior() == null || registro.getDireccion().getNumExterior() == null || registro.getDireccion().getColonia().length() == 0
                || registro.getDireccion().getCP() == null || registro.getDireccion().getMunicipio().length() == 0)
        {
            return false;
        }
        return new RegistroService().addRegistro(registro);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }

    public List<Registro> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Registro> list) 
    {
        this.list = list;
    }

    public Registro getRegistro() 
    {
        return registro;
    }

    public void setRegistro(Registro registro) 
    {
        this.registro = registro;
    }
}