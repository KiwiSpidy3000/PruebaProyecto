/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;
import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Rol;
import org.omaya.service.RolService;

/**
 *
 * @author ofeli
 */
public class RolHelper implements Serializable{
   
    private List<Rol>list;
    private Rol rol;

    public RolHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new RolService().getRolList();
        return list != null && list.size() > 0;
    }
    
    public boolean addRol( HttpServletRequest request )
    {
        rol = new Rol( ); 
        rol.setIdRoles( getInteger(request.getParameter( "IdRoles" ) ) );
        if( rol.getIdRoles() == null || rol.getIdRoles() == 0 )
        {
            return false;
        }
        rol.setTipo( request.getParameter( "Tipo" ) );
        if( rol.getTipo() == null || rol.getTipo().length() == 0 )
        {
            return false;
        }
        return new RolService().addRol(rol);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    public List<Rol> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Rol> list) 
    {
        this.list = list;
    }

    public Rol getIdRoles() 
    {
        return rol;
    }

    public void setIdRoles(Rol rol) 
    {
        this.rol = rol;
    }
    
}