/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.omaya.helper;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.omaya.dao.Persona;
import org.omaya.service.PersonaService;


/**
 *
 * @author ldrnts
 */
public class PersonaHelper implements Serializable
{
    private List<Persona>list;
    private Persona persona;

    public PersonaHelper() 
    {
    }
    
    public boolean loadList( )
    {
        list = new PersonaService().getPersonaList();
        return list != null && list.size() > 0;
    }
    
    public boolean addPersona( HttpServletRequest request )
    {
        persona = new Persona( ); 
        persona.setIdPersona( getInteger(request.getParameter( "IdPersona" )) );
        if( persona.getIdPersona() == null )
        {
            return false;
        }

        persona.setNombre( request.getParameter( "Nombre" ) );
        if( persona.getNombre() == null || persona.getNombre().length() == 0 )
        {
            return false;
        }
        
        persona.setAPaterno( request.getParameter( "APaterno" ) );
        if( persona.getAPaterno() == null || persona.getAPaterno().length() == 0 )
        {
            return false;
        }
        
        persona.setAMaterno( request.getParameter( "AMaterno" ) );
        if( persona.getAMaterno() == null || persona.getAMaterno().length() == 0 )
        {
            return false;
        }
        
        persona.setEdad( getInteger(request.getParameter( "Edad" )) );
        if( persona.getEdad() == null )
        {
            return false;
        }
        
        persona.setCorreo( request.getParameter( "Correo" ) );
        if( persona.getCorreo() == null || persona.getCorreo().length() == 0 )
        {
            return false;
        }
        
        persona.setContraseña( request.getParameter( "Contraseña" ) );
        if( persona.getContraseña() == null || persona.getContraseña().length() == 0 )
        {
            return false;
        }
        
        return new PersonaService().addPersona(persona);
    }
    
    public Integer getInteger( String campo )
    {
        Integer val = 0;
        if( campo == null || campo.length() == 0 )
        {
            return null;
        }
        try
        {
            val = new Integer(campo);
            return val;
        }
        catch(NumberFormatException ex)
        {
            ex.printStackTrace();
        }
        return null;
    }

    public List<Persona> getList()
    {
        if( list == null || list.size( )== 0 )
        {
            if( !loadList( ) )
            {
                return null;
            }
        }
        return list;
    }

    public void setList(List<Persona> list) 
    {
        this.list = list;
    }

    public Persona getIdPersona() 
    {
        return persona;
    }

    public void setIdPersona(Persona persona) 
    {
        this.persona = persona;
    }
    
}
